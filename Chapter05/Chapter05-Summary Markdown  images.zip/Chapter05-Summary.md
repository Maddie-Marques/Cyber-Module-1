# ***<u>The Device Ladder: Hub -\> Switch -\> Router (Collision & Broadcast Domains):</u>***

<table>
<colgroup>
<col style="width: 9%" />
<col style="width: 7%" />
<col style="width: 39%" />
<col style="width: 21%" />
<col style="width: 22%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>Device</strong></th>
<th><strong>Layer</strong></th>
<th><strong>How it works</strong></th>
<th><strong>Collision domains</strong></th>
<th><strong>Broadcast domains</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><strong>Hub</strong></td>
<td>1</td>
<td><p>A multi-port repeater.</p>
<p>Regenerates and blindly forwards any signal out every port</p>
<p>(physical star, logical bus)</p></td>
<td><strong>One</strong> shared by everyone</td>
<td><strong>One</strong></td>
</tr>
<tr class="even">
<td><strong>Bridge</strong></td>
<td>2</td>
<td><p>Uses MAC addresses to keep traffic separated 0n either side.</p>
<p>Largely obsolete, replaced by switches</p></td>
<td>Breaks them up</td>
<td>One</td>
</tr>
<tr class="odd">
<td><strong>Switch</strong></td>
<td>2</td>
<td><p>A hardware-based multi-port bridge (using <strong>ASICs</strong>, Application-Specific Integrated Circuits).</p>
<p>ads source/destination MACs and the receiving port, builds a filter table.</p></td>
<td><strong>One per port</strong></td>
<td><p><strong>One</strong>.</p>
<p>Still floods broadcasts everywhere by default</p></td>
</tr>
<tr class="even">
<td><strong>Router</strong></td>
<td>3</td>
<td>Connects disparate segments into an internetwork, forwarding by <strong>IP address</strong></td>
<td>Breaks them up too</td>
<td><strong>One per interface</strong>. The only one that breaks up broadcast domains</td>
</tr>
</tbody>
</table>

## **Quick Examples:**

| **Setup**                                   | **Collision domains** | **Broadcast domains** |
|---------------------------------------------|-----------------------|-----------------------|
| 4 hosts on a hub                            | 1                     | 1                     |
| Same 4 hosts on a switch                    | 4                     | 1                     |
| Router between two switches (4 hosts total) | 4                     | 2                     |

### The book's bigger worked example:

- An all-hub network = 1 collision domain.

- A bridge network with 2 hub segments = up to 3 collision domains.

- A 5-port switch network = 5 collision domains (one per port).

- A router connecting all three networks: **9 collision domains, 3 broadcast domains** (one per router-connected segment).

Switches don't isolate broadcast/multicast traffic even though they segment collision domains. Only a router (layer 3) stops a broadcast storm from spreading.

## <u>Interface Defaults:</u>

- **Switch interfaces** are **enabled by default** and auto-negotiate speed/duplex. They rarely need manual config.

- **Router interfaces** are **shut down by default**. They need a specific IP address and no shutdown before they'll do anything, because a router needs a real layer 3 design (subnetting, addressing scheme) to be useful at all.

# ***<u>Firewall, IDS, IPS, HIDS:</u>***

## <u>Firewall:</u>

A firewall filters packets by admin-defined rules at the network boundary, sitting between a public (Internet) side and a private (LAN) side. some firewalls even reach up to the Application layer. Without one, an Internet-connected network is wide open-

Networks often add a second firewall to create a screened subnet/DMZ (demilitarised zone): an intermediary zone for public-facing resources like web, email and DNS servers. That gives you the zones: external (untrusted), internal (trusted), and the DMZ.

## <u>Intrusion Detection & Prevention:</u>

<table>
<colgroup>
<col style="width: 33%" />
<col style="width: 26%" />
<col style="width: 39%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>System</strong></th>
<th><strong>Where it sits</strong></th>
<th><strong>What it does</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><strong>IDS</strong> (Intrusion Detection System)</td>
<td>Watches network traffic</td>
<td><strong>Only monitors and alerts</strong>. Doesn't act.</td>
</tr>
<tr class="even">
<td><strong>IPS</strong> (Intrusion Prevention System)</td>
<td><strong>Inline</strong>, in real time</td>
<td>Actively blocks traffic, sends alarms, applies remediation rules, drops malicious packets, even resets offending connections.</td>
</tr>
<tr class="odd">
<td><strong>HIDS</strong> (Host-based IDS)</td>
<td>On a single host</td>
<td><p>Watches that hosts own applications, logs, and events, not network traffic.</p>
<p>Usually deployed on servers, since managing it on every client is a hassle.</p>
<p>If the host is compromised, its local IDS data can be too.</p></td>
</tr>
<tr class="even">
<td><strong>PIDS</strong> (Protocol-based IDS)</td>
<td>One server</td>
<td>Monitors one protocol</td>
</tr>
<tr class="odd">
<td><strong>APIDS</strong> (Application Protocol-based (DS)</td>
<td>A group of servers</td>
<td>Monitors serves running the same application.</td>
</tr>
</tbody>
</table>

# ***<u>DHCP, End-to-End:</u>***

**DHCP (Dynamic Host Configuration Protocol)** servers automate IP assignment instead of manual static addressing. It's technically an Application-layer protocol (through **DORA**, Discover/Offer/Request/Acknowledge, operates at layer 2), and it uses **UDP ports 67 (server) and 68 (client)**, based on **BootP** (Bootstrap Protocol).

## <u>Key Terms:</u>

<table>
<colgroup>
<col style="width: 34%" />
<col style="width: 65%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>Term</strong></th>
<th><strong>What it is</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><strong>Pool</strong></td>
<td>The configured range of addresses the server hands out.</td>
</tr>
<tr class="even">
<td><strong>Exclusion</strong></td>
<td>Addresses set aside as off-limits, like a router interface.</td>
</tr>
<tr class="odd">
<td><strong>Reservation</strong> (aka MAC reservation)</td>
<td><p>Guarantees a host always gets the same IP, tied to its MAC.</p>
<p>Useful for routers/servers not statically assigned.</p></td>
</tr>
<tr class="even">
<td><strong>Lease time</strong></td>
<td>How long the info is valid before it expires (e.g., 23 hours).</td>
</tr>
<tr class="odd">
<td><strong>Scope options</strong></td>
<td>Subnet-specific config.</td>
</tr>
<tr class="even">
<td><strong>Server options</strong></td>
<td>Apply across all scopes (e.g., a shared DNS server).</td>
</tr>
</tbody>
</table>

DHCP hands out much more than IP/mask/gateway: **TTL** (Time to Live) values, DNS servers, **TFTP** (Trivial File Transfer Protocol) server info (important for IP phones), and more, based on the client's **Parameter Request List**.

## DHCP Relay (ip helper-address):

Routers don't forward broadcast by default, so a client on a different subnet from the server can't reach it at all. **DHCP relay** fixes that: the router's **ip helper-address** command converts the broadcast into a unicast (or a directed broadcast to multiple servers) aimed at the real DHCP server. One central server can then handle multiple subnets, instead of needing one per segments.

## <u>What a Real Capture Shows:</u>

1.  The client has IP 0.0.0.0 and knows only its own MAC

2.  It broadcasts to 255.255.255.255 on port 67/68.

3.  <img src="./media/image1.jpeg" style="width:3.91319in;height:2.79722in" />The server replies with De requested IP, subnet mask, lease time, DHCP server IP, gateway, DNS servers, domain name, and NetBIOS info.

## <u>Troubleshooting:</u>

Lease expiration is a useful clue.

If hosts drop off the network one at a time as their leases expire, or machines shut down over the weekend can't get new addresses on Monday, check the DHCP server.

## <u>IPAM:</u>

**IPAM (IP Addressing Management)** tools manage DHCP and DNS together.

They track IP assignments and which device or user has which address, and keep both services in sync.

# ***<u>DNS, End-to-End</u>***

**DNS (Domain Name System)** is the “phone book of the Internet.”

It resolves hostnames to IP addresses.

It's an Application-layer protocol using **UDP 53** for queries (and TCP for zone transfer updates).

- hostname is part of on **FQDN** (Fully Qualified Domain Name): hostname + domain name

- Name resolution can happen via a static **hosts file**, a local broadcast, or DNS.

DNS is the standard today.

- Domains are **hierarchical**.

Common top-level domains:

- .com,

- .edu,

- .gov,

- .int,

- .mil,

- .net,

- .org,

plus country codes (.ca, jp, .uk, .ru)

and newer ones (.info, .biz, .travel).

- **DHCP option 15** can supply a DNS suffix, so clients can also resolve short names

(e.g., “todd” instead of “todd.lamel.com”)

## <u>Record Types:</u>

<table>
<colgroup>
<col style="width: 40%" />
<col style="width: 59%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>Record</strong></th>
<th><strong>What it does</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><strong>A</strong></td>
<td>Hostname -&gt; IPv4 address</td>
</tr>
<tr class="even">
<td><strong>AAAA</strong></td>
<td>Hostname -&gt; IPv6 address</td>
</tr>
<tr class="odd">
<td><strong>PTR</strong> (Pointer)</td>
<td><p>Reverse lookup, IP -&gt;hostname.</p>
<p>Lives in a reverse lookup zone</p></td>
</tr>
<tr class="even">
<td><strong>MX</strong> (Mail Exchange)</td>
<td><p>Points to a domain's mail server(s), with priority ordering.</p>
<p>If the first doesn't respond, delivery tries the next.</p></td>
</tr>
<tr class="odd">
<td><strong>CNAME</strong> (Canonical Name)</td>
<td><p>Aliases one hostname to another</p>
<p>(e.g., <a href="ftp://ftp.company.com">ftp.company.com</a> -&gt; www.company.com)</p></td>
</tr>
<tr class="even">
<td><strong>NS</strong> (Name Server)</td>
<td>Identifies the authoritative server for a domain's mail</td>
</tr>
<tr class="odd">
<td><strong>SOA</strong> (Start of Authority)</td>
<td>Admin contact, last update time, refresh/TTL intervals for a zone</td>
</tr>
<tr class="even">
<td><strong>TXT(SPF)</strong> (Sender Policy Framework)</td>
<td>Lists authorised senders for a domains mail.</td>
</tr>
<tr class="odd">
<td><strong>TXT(DKIM)</strong> (DomainKeys Identified Mail)</td>
<td>Cryptographically authenticates outbound mail to prevent spoofing</td>
</tr>
<tr class="even">
<td><strong>SRV</strong> (Service)</td>
<td>Points to a host and port for a specific service</td>
</tr>
<tr class="odd">
<td><strong>CAA</strong> (Certification Authority Authorization)</td>
<td>says which Certificate Authorities may issue certs for a domain</td>
</tr>
</tbody>
</table>

**Authoritative** servers hold the official records.

**Non-authoritative** servers cache or forward to improve performance.

## <u>Zones & Lookups:</u>

- **Forward lookup zone:** names -\> IPs,

**Reverse lookup zone:** IPs -\>names.

- **Zone transfers** sync a primary DNS server's zone data to secondary servers for redundancy and load distribution.

- Cached answers carry a **TTL** telling the client how long to keep using them before re-querying.

- **Recursive lookup:** one DNS server queries others on the client's behalf.

**Iterative lookup:** the client itself talks to multiple servers directly.

## <u>Dynamic DNS & Placement:</u>

- **Dynamic DNS** lets hosts self-register their name as they get their from DHCP. For older OSs that can't, DHCP registers on their behalf. Some records (MX, CNAME) must still be created manually.

- DNS servers can live in the **DMZ** (holding only DMZ device records) or **internally**, and sometimes both are noded when intered and external domains overlap.

- Smaller orgs may outsource DNS entirely to a third-party/cloud providers.

## <u>Securing DNS:</u>

<table>
<colgroup>
<col style="width: 24%" />
<col style="width: 54%" />
<col style="width: 20%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>Tech</strong></th>
<th><strong>What it does</strong></th>
<th><strong>Port</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><p><strong>DNSSEC</strong></p>
<p>(DNS Security Extensions)</p></td>
<td><p>Adds cryptographic authentication, authenticated denial of existence, and data integrity to DNS answers.</p>
<p>Built via <strong>EDNS</strong> (Extension Mechanisms for DNS), which expanded DNS's originally too-small protocol parameters,</p></td>
<td></td>
</tr>
<tr class="even">
<td><p><strong>DoH</strong></p>
<p>(DNS over HTTPS)</p></td>
<td><p>Encrypts queries/responses over HTTPS.</p>
<p>Firefox enables it by default.</p>
<p>Hard to tell apart from ordinary HTTPS traffic.</p></td>
<td>TCP 443</td>
</tr>
<tr class="odd">
<td><p><strong>DoT</strong></p>
<p>(DNS over TLS)</p></td>
<td>Encrypts via TLS</td>
<td>TCP 853 / UDP 8853</td>
</tr>
<tr class="even">
<td><p><strong>DoQ</strong></p>
<p>(DNS over QUIC)</p></td>
<td><p>Google/Chrome.</p>
<p>Encrypts at the transport layer, functionally similar to DoH/DoT.</p></td>
<td>UDP 443</td>
</tr>
</tbody>
</table>

DNSSEC authenticates the answer. DoH/DoT/DoQ encrypt the query itself, which is great for privacy but **blinds security tools** (like an NGFW or IPS doing URL filtering) from inspecting it.

# ***<u>Wireless Contention: CSMA/CA vs. CSMA/CD:</u>***

Wired Ethernet uses **CSMA/CD** because NIC can detect a collision while transmitting. A wireless radio can't listen and transmit on the same frequency at once, so Wi-Fi uses **CSMA/CA (Carrier Sense Multiple Access with Collision Avoidance)** instead.

|                               | **CSMA/CA** (wireless)                                                      | **CSMA/CD** (wired)                          |
|-------------------------------|-----------------------------------------------------------------------------|----------------------------------------------|
| **Can it detect collisions?** | No                                                                          | Yes                                          |
| **Back-off**                  | **Mandatory** random back-off before transmitting when the channel is busy. | Only kicks in **after** an actual collision. |
| **Acknowledgement**           | **Every single frame** must be explicitly acknowledged                      | Not per frame                                |
| **Efficiency**                | Lower                                                                       | Higher                                       |

## <u>How CSMA/CA Works:</u>

1.  **Carrier sense:** the station listens for existing traffic.

2.  If the channel is busy, it counts down a **random back-off timer**.

3.  Once the timer hits zero and the channel is clear, it transmits.

4.  The **AP acks** the sender. If it's relaying to another wireless client, that client acks the AP too. All other stations must stay silent until each ack completes.

**Crossing to the wire:** the AP strips the **802.11** header and builds a new Ethernet reader (it's own MAC as source the gateway's MAC as destination). Then normal wired CSMA/CD takes over.

**Why Wi-Fi feels slower than advertised:** every frame needs that check-and-acknowledge cycle, and airtime gets divided among all active stations. Real throughput is typically **about half** the advertised rate, and it drops further as more stations join.

## <u>How CSMA/CD Works (Recap):</u>

1.  The device checks the wire, transmits if clear, and keeps listening while transmitting.

2.  On a collision, both devices send a jam signal and increment a retransmission counter.

3.  Each calculates an independent random back-off delay before retrying.

## ***<u>The Rest of the Toolbox:</u>***

## <u>Connectivity & Wireless:</u>

<table>
<colgroup>
<col style="width: 43%" />
<col style="width: 7%" />
<col style="width: 49%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>Device</strong></th>
<th><strong>Layer</strong></th>
<th><strong>What it does</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><strong>NIC</strong> (Network Interface Card)</td>
<td>2</td>
<td><p>Physically connects a host to the network, using its MAC address.</p>
<p>Link LED shows connection status, activity LED flickers with traffic.</p></td>
</tr>
<tr class="even">
<td><strong>AP</strong> (Access Point)</td>
<td>2</td>
<td><p>Essentially a wireless hub.</p>
<p>Modulates/demodulates between digital and analog wireless signals, creates one collision domain, runs half-duplex.</p>
<p>An autonomous AP manages its area on its own, with no control controller.</p></td>
</tr>
<tr class="odd">
<td><strong>Wireless range extender</strong></td>
<td></td>
<td><p>Repeats the signal to extend coverage.</p>
<p>Should overlap the original AP's coverage by ~15%</p></td>
</tr>
<tr class="even">
<td><strong>WLC</strong> (Wireless LAN Controller)</td>
<td></td>
<td><p>Centralises config for many lightweight AP's in large deployments.</p>
<p>Pushes config out and tunnels user data back to itself, cutting admin overhead a lot.</p></td>
</tr>
<tr class="odd">
<td><strong>Media converter</strong></td>
<td>1</td>
<td><p>Converts between cabling types.</p>
<p>(e.g., Ethernet to fiber)</p></td>
</tr>
<tr class="even">
<td><strong>Analog modem</strong></td>
<td>1</td>
<td><p>Like a repeater.</p>
<p>Modulates/demodulates digital data over phone lines.</p>
<p>Slow, but still used.</p></td>
</tr>
<tr class="odd">
<td><strong>Cable modem</strong></td>
<td></td>
<td>Connects a site to a cable provider's coax network, using DOCSIS (Data Over Cable Service Interface specification) to share voice/data with cable TV signals.</td>
</tr>
<tr class="even">
<td><strong>DSL modem</strong></td>
<td></td>
<td>Connects over twisted-pair copper phone lines, carrying data as high-frequency signal above the voice range.</td>
</tr>
</tbody>
</table>

## <u>Traffic, Performance & Security:</u>

<table>
<colgroup>
<col style="width: 39%" />
<col style="width: 60%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>Device</strong></th>
<th><strong>What it does</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><strong>Load balancer</strong></td>
<td><p>Publishes a <strong>virtual IP</strong> and spreads incoming connections accross a red server pool (round robin, least connections, response time, weighted, etc.).</p>
<p>Runs <strong>health checks</strong> to pull failed served out of automatically, and enables dynamic scaling.</p>
<p>Key for fault tolerance and high-traffic sites with no single point of failure.</p></td>
</tr>
<tr class="even">
<td><strong>MLS</strong> (Multilayer Switch)</td>
<td><p>Layer 2 switching + layer 3 routing in one device, using ASIC hardware (vs. a router's microprocessor-based packet switching).</p>
<p>Gives you routing <strong>plus</strong> per-port collisions domains, which a plain router can't.</p></td>
</tr>
<tr class="odd">
<td><strong>Proxy server</strong></td>
<td><p>Application-layer device that caches and filters outbound requests, speeding things up and restricting site access.</p>
<p><strong>Web proxy</strong> caches web content/session info.</p>
<p><strong>Caching proxy</strong> speeds up repeated requests generally.</p>
<p><strong>Reverse proxy</strong> takes requests from the Internet and forwards them to internal servers (the opposite direction).</p></td>
</tr>
<tr class="even">
<td><strong>Encryption/content filtering appliances</strong></td>
<td>Offload processor-heavy encryption or content scarring from routers/servers, with firer control (e.g., spam filtering, content-based site blocking).</td>
</tr>
<tr class="odd">
<td><strong>Packet Shaper</strong></td>
<td>Delays certain packets to enforced traffic profile, improving latency bandwidth for prioritised traffic.</td>
</tr>
<tr class="even">
<td><strong>VPN concentrator/headend</strong></td>
<td><p>Terminates mary encrypted remote VPN tunnels at once, centrally.</p>
<p>Better performance and features than a general-purpose router/server.</p></td>
</tr>
<tr class="odd">
<td><p><strong>NGFW / Layer 7 firewall</strong></p>
<p>(Next Generation Firewall)</p></td>
<td><p>Adds application awareness on top of stated filtering: inspects by specific application, not just port.</p>
<p>Does <strong>deep packet inspection once</strong>, more efficient than <strong>UTM</strong> (Unified Threat Management) devices running several separate engines.</p></td>
</tr>
</tbody>
</table>

## <u>Voice:</u>

<table>
<colgroup>
<col style="width: 35%" />
<col style="width: 64%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>Device</strong></th>
<th><strong>What it does</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><strong>VoIP PBX</strong> (Private Branch Exchange)</td>
<td><p>Private phone switch routing calls betach internal extensions and a limited number of external lines.</p>
<p>Handles VoIP users and can bridge to traditional phone lines.</p></td>
</tr>
<tr class="even">
<td><strong>VoIP endpoint</strong></td>
<td>Desktop/wireless VoIP phones or conferencing systems on converged voice + data networks.</td>
</tr>
<tr class="odd">
<td><strong>VoIP gateway</strong></td>
<td>Converts voice /fax calls between IP networks and the <strong>PSTN</strong> (Public Switched Telephone Network), using protocols like <strong>MGCP</strong> (Media Gateway Control Protocol), <strong>SIP</strong> (Session Initiation Protocol), or LTP</td>
</tr>
</tbody>
</table>

## <u>NTP (Network Time Protocol):</u>

- Synchronises clocks across devices on **UDP 123**.

Critical for security/log correlation and time-sensitive distributed tasks.

- **Stratum levels** show time-source accuracy.

**Stratum 0** is the master reference clock (a nuclear/satellite clock).

Each level down syncs from the one above and loses a bit of accuracy.

- Clients typically re-sync **every 10 minutes** after the initial sync.

## <u>Networked & IoT Devices:</u>

IoT (Internet of Things) and ICS/SCADA devices connect everything from doorbells to power grids, usually with very little built-in security of their own.

- **VoIP phones**: low bandwidth, but need **QoS** because they're sensitive to delay and jitter.

- **Printers**: shared via a NIC-equipped printer or a dedicated print server.

- **Physical access control**: badge scans are authenticated against a directory service (e.g., Active Directory) to unlock doors/gates.

- **Cameras**: run over TCP/IP, often with **PTZ** (pan-tilt-zoom) control and facial recognition.

- **HVAC sensors** (Heating, Ventilation, and Air Conditioning): automated/remote climate control, with after-hours cost savings.

- **IoT**: the explosion of connected consumer devices (wearables, smart assistants, doorbells, thermostats). Low bandwidth each, but it adds up with enough devices.

- **IS/SCADA** (Industrial Control Systems / Supervisory Control and Data Acquisition): monitor and control industrial infrastructure (power grids, factory floors, water utilities) using **PLCs** (Programmable Logic Controllers) and sensors, feeding graphical monitoring systems. Enables proactive maintenance and workflow adjustments.

# ***<u>Network Segmentation & SOHO Planning:</u>***

(Mostly Textbook. Study Guide folds this into the device concepts above)

## <u>Planning a SOHO Network:</u>

Designing a **SOHO** (Small Office/Home Office) network starts with identifying requirement and constraints: number of hosts, internet access needs, shared resources, wired/wireless coexistence, and security priorities. That decides whether you need just a switch, or also a router, AP, and firewall.

## <u>Fixing LAN Congestion:</u>

Common causes:

- Too many hosts in one broadcast domain

- Broadcast storms

- Multicasting

- Low bandwidth

- Daisy-chaining hubs

The fix is **network segmentation**: switches to multiply collision domains and routers to multiply broadcast domains and enable internetworking /VLAN routing.

## <u>Routers vs. Switches</u>

Routers provide four key functions:

1.  **Packet switching**

2.  **Packet filtering** (via access limits)

3.  **Internetwork communication**

4.  **Path selection** (via routing tables)

Switches don't create internetworks. They optimise a single LAN's performance by switching frames port-to-port, without touching broadcast domains.

## <u>How Switches Learn (Layer 2):</u>

- Switches/bridges build a **filter table mapping** MAC addresses to ports. This is **transparent bridging**.

- If a destination is unknown, the frame floods to all ports. When the destination replies, the table updates.

- Broadcasts always flood to every connected segment, so all switch-connected devices stay in **one broadcast domain**, however many collision domains the switch creates. Layer 2 devices can't stop a broadcast storm. Only a router can.

## <u>Hubs (Layer 1):</u>

Hubs are multi-port repeaters. They blindly regenerate and forward any signal to all ports with no data inspection, creating one shared collision and broadcast domain for everyone (physical star, logical bus).

## <u>Environmental Considerations:</u>

- **Temperature**: needs strong HVAC/ventilation, often a **hot/cold aisle** data center design, plus **UPS** (Uninterruptable Power Supply) and generator backup.

- **Humidity**: too dry causes static damage, too damp causes corrosion and shorts. Aim for **above 50%** humidity, controlled at the upper end too.

# ***<u>Core Insights: 19</u>***

<table>
<colgroup>
<col style="width: 35%" />
<col style="width: 64%" />
</colgroup>
<thead>
<tr class="header">
<th><strong>Concept</strong></th>
<th><strong>The thing to remember</strong></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><strong>Hub vs. switch vs. router</strong></td>
<td><p>Hub = 1 collision 11 broadcast.</p>
<p>Switch = 1 collision per port, still 1 broadcast.</p>
<p>Router = 1 broadcast per interface.</p></td>
</tr>
<tr class="even">
<td><strong>Only routers can stop broadcasts</strong></td>
<td>Layer 2 devices can't stop a broadcast storm.</td>
</tr>
<tr class="odd">
<td><strong>Interface defaults</strong></td>
<td><p>Switch ports are on by default\</p>
<p>Router interfaces are shut down until given an IP and no shutdown.</p></td>
</tr>
<tr class="even">
<td><strong>Firewall &amp; DMZ</strong></td>
<td><p>Filters by rule at the boundary.</p>
<p>A second firewall creates a screened subnet/DMZ for public servers.</p></td>
</tr>
<tr class="odd">
<td><strong>IDS vs. IPS vs. HIDS</strong></td>
<td><p>IDS = monitor and alert.</p>
<p>IPS = inline, actively blocks.</p>
<p>HIDS = one host's logs not network traffic.</p></td>
</tr>
<tr class="even">
<td><strong>DHCP</strong></td>
<td><p>Pool, exclusions, reservations, lease.</p>
<p>UDP 67/68.</p>
<p>DORA.</p>
<p>Remote subrets med ip helper-address (relay).</p></td>
</tr>
<tr class="odd">
<td><strong>DNS records</strong></td>
<td><p>A (IPv4),</p>
<p>AAAA (IPv6),</p>
<p>PTR (reverse),</p>
<p>MX (mail)</p>
<p>CNAME (alias),</p>
<p>NS (authoritative),</p>
<p>SOA,</p>
<p>TXT (SPF/DKIM),</p>
<p>SRV,</p>
<p>CAA.</p></td>
</tr>
<tr class="even">
<td><strong>DNS mechanics</strong></td>
<td><p>UDP 53.</p>
<p>Forward vs. reverse zones.</p>
<p>Zone transfers sync secondaries.</p>
<p>Recursive vs. iterative</p></td>
</tr>
<tr class="odd">
<td><strong>DNS Security</strong></td>
<td><p>DNSSEC authenticates answers.</p>
<p>DoH (443),</p>
<p>DoT (853),</p>
<p>DoQ (UDP 443) encrypt queries but blind security tools.</p></td>
</tr>
<tr class="even">
<td><strong>CSMA/CA vs. CSMA/CD</strong></td>
<td><p>Wireless can't detect collisions: back off first,ack every frame roughly half of the advertised speed.</p>
<p>Wired backs off only after a collision.</p></td>
</tr>
<tr class="odd">
<td><strong>Load balancer</strong></td>
<td>Virtual IP, spreads load, health checks pull failed servers.</td>
</tr>
<tr class="even">
<td><strong>MLS</strong></td>
<td>Routing + switching in hardware (ASICSs), with per-port collision domains.</td>
</tr>
<tr class="odd">
<td><strong>Proxy</strong></td>
<td><p>Forward proxy caches/filters outbound.</p>
<p>Reverse proxy forwards in bound to internal servers.</p></td>
</tr>
<tr class="even">
<td><strong>NGFW</strong></td>
<td>Application-aware, single-pass deep packet inspection.</td>
</tr>
<tr class="odd">
<td><strong>NTP</strong></td>
<td><p>UDP 123.</p>
<p>Stratum 0 = master clock.</p>
<p>Accuracy drops each level down.</p></td>
</tr>
<tr class="even">
<td><strong>IoT / ICS / SCADA</strong></td>
<td>Doorbells to power grids, usually with built-in security.</td>
</tr>
<tr class="odd">
<td><strong>Segmentation</strong></td>
<td>Switches multiply collision domains, routers multiply broadcast domains.</td>
</tr>
<tr class="even">
<td><strong>Environment</strong></td>
<td>Hot/cold aisles, UPS, humidity above 50%</td>
</tr>
</tbody>
</table>

# ***<u>Abbreviations:</u>***

| **Abbreviation** | **Stands for**                                         |
|------------------|--------------------------------------------------------|
| **A / AAAA**     | Address record (IPv4) / IPv6 address record.           |
| **AP**           | Access Point                                           |
| **APIDS**        | Application Protocol-based Intrusion Detection System  |
| **ASIC**         | Application Specific Integrated Circuit                |
| **BootP**        | Bootstrap Protocol                                     |
| **CAA**          | Certification Authority Authorisation                  |
| **CNAME**        | Canonical Name                                         |
| **CSMA/CA**      | Carrier Sense Multiple Access with Collision Avoidance |
| **CSMA/CD**      | Carrier Sense Multiple Access with Collision Detection |
| **DHCP**         | Dynamic Host Configuration Protocol                    |
| **DKIM**         | DomainKeys Identified Mail                             |
| **DMZ**          | Demilitarized Zone                                     |
| **DNS**          | Domain Name System                                     |
| **DNSSEC**       | DNS Security Extentions                                |
| **DOCSIS**       | Data Over Cable Service Interface Specification        |
| **DoH**          | DNS over HTTPS                                         |
| **DoQ**          | DNS over QUIC                                          |
| **DORA**         | Discover, Offer, Request, Acknowledge                  |
| **DoT**          | DNS over TLS                                           |
| **DSL**          | Digital Subscriber Line                                |
| **EDNS**         | Extension Mechanisms for DNS                           |
| **FQDN**         | Fully Qualified Domain Name                            |
| **HIDS**         | Host-based Intrusion Detection System                  |
| **HTTPS**        | Hypertext Transfer Protocol Secure                     |
| **HVAC**         | Heating, Ventilation, and Air Conditioning             |
| **ICS**          | Industrial Control System                              |
| **IDS**          | Intrusion Detection System                             |
| **IoT**          | Internet of Things                                     |
| **IPAM**         | IP Address Management                                  |
| **IPS**          | Intrusion Prevention System                            |
| **MGCP**         | Media Gateway control Protocol                         |
| **MLS**          | Multilayer Switch                                      |
| **MX**           | Mail Exchanger                                         |
| **NGFW**         | Next-Generation Firewall                               |
| **NIC**          | Network Interface Card                                 |
| **NS**           | Name Server                                            |
| **NTP**          | Network Time Protocol                                  |
| **PBX**          | Private Branch Exchange                                |
| **PIDS**         | Protocol-based Intrusion Detection System              |
| **PLC**          | Programmable Logic Controller                          |
| **PSTN**         | Public Switched Telephone Network                      |
| **PTR**          | Pointer record                                         |
| **PTZ**          | Pan-Tilt-Zoom                                          |
| **QoS**          | Quality of Service                                     |
| **QUIC**         | Quick UDP Internet Connections                         |
| **SCADA**        | Supervisory Control and Data Acquisition               |
| **SIP**          | Session Initiation Protocol                            |
| **SOA**          | Start of Authority                                     |
| **SOHO**         | Small Office/Home Office                               |
| **SPF**          | Sender Policy Framework                                |
| **SRV**          | Service Record                                         |
| **TFTP**         | Trivial File Transfer Protocol                         |
| **TLS**          | Transport Layer Security                               |
| **TTL**          | Time to Live                                           |
| **TXT**          | Text record                                            |
| **UDP**          | User Datagram Protocol                                 |
| **UPS**          | Uninterruptable Power Supply                           |
| **UTM**          | Unified Threat Management                              |
| **VLAN**         | Virtual Local Area Network                             |
| **VoIP**         | Voice over Internet Protocol                           |
| **VPN**          | Virtual Private Network                                |
| **WLC**          | Wireless LAN Controller                                |
